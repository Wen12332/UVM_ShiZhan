set UVM_src      D:/questasim/anzhuang/verilog_src/uvm-1.1d/src

##--- dump waveform and debug mode ---##
vlog -sv12compat -mfcu +incdir+$UVM_src -L mtiUvm -f flist.f
vsim -c +nowarnTSCALE -voptargs=+acc -classdebug -L ./work -l load.log top_tb
add log -r /top_tb/*
run -all

